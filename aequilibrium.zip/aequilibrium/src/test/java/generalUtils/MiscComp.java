package generalUtils;

import java.io.File;
import java.util.Random;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import testScenarios.testCases;

public class MiscComp {
ExtentTest child;
ExtentTest parent;


	
	public void report(ExtentTest child,boolean result, String stepName)
	{
		if (result==true)
		{
			child.log(LogStatus.PASS,stepName,"is passed" );
			
		}
		else {
			
			screenshotfilepath = TakeErrorScreenShot(stepName);
			child.log(LogStatus.FAIL,stepName+" :is Failed",child.addScreenCapture(screenshotfilepath));
		}
	}
	
	String screenshotfilepath;
	WebDriver driver;
	public String TakeErrorScreenShot(String fname)
	{
		File scrFile = ((TakesScreenshot)testCases.driver).getScreenshotAs(OutputType.FILE);
		try {
			screenshotfilepath = new File(".").getCanonicalPath()+"/ScreenShots/"+fname+new Random().nextInt(99999)+".png";
			FileUtils.copyFile(scrFile, new File(screenshotfilepath));
        	//FileUtils.copyFile();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        scrFile = null;
        System.out.println(screenshotfilepath);
        return screenshotfilepath;

	}


}
