package generalUtils;

import java.io.FileInputStream;
import java.util.Properties;

public class ReadProperties
{
	String filePath;
	FileInputStream myFile;
	Properties myProp;
	public ReadProperties(String myfilePath)
	{
		filePath = myfilePath;
	}
	
	public String readValue(String key) 
	{
		try {
			myFile = new FileInputStream(filePath);
			myProp = new Properties();
			myProp.load(myFile);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return myProp.getProperty(key);
	}

}
