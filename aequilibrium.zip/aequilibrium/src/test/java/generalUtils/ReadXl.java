package generalUtils;

import java.io.FileInputStream;

import jxl.Sheet;
import jxl.Workbook;

public class ReadXl
{
	Sheet mySheet;
	FileInputStream myfile;
	Workbook myBook;
	String xlfile;
	String sheetName;
	public ReadXl(String xlfile)
	{
		this.xlfile = xlfile;
	}
	public ReadXl(String xlfile,String sheetName)
	{
		this.xlfile = xlfile;
		this.sheetName = sheetName;
	}
	public Sheet getMySheet(String sheetName)
	{
		try {
			myfile = new FileInputStream(xlfile);
			myBook = Workbook.getWorkbook(myfile);
		} catch (Exception emsg) {
			// TODO Auto-generated catch block
			emsg.printStackTrace();
		}
		return myBook.getSheet(sheetName);
	}
	public int getRowCount(String sheetName)
	{
		mySheet = getMySheet(sheetName);
		return mySheet.getRows();
	}
	public int getColumnCount(String sheetName)
	{
		mySheet = getMySheet(sheetName);
		return mySheet.getColumns();
	}
	public String getCellData(String sheetName,int col,int row)
	{
		mySheet = getMySheet(sheetName);
		return mySheet.getCell(col, row).getContents();
	}

}
