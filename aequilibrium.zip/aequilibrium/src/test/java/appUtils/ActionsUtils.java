package appUtils;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionsUtils {
	
	WebDriver driver;
	Actions actions;
	public ActionsUtils(WebDriver driver) {
		this.driver=driver;
		actions= new Actions(driver);
	}
public void clickEnter() {
	actions.sendKeys(Keys.ENTER).build().perform();
}
public void clickTab() {
	actions.sendKeys(Keys.TAB).build().perform();
}
}
