package appUtils;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import generalUtils.ReadProperties;

public class Driver
{
	ReadProperties prop;
	WebDriver driver;
	public Driver()
	{
		
		prop=new ReadProperties("Data/swagLabs.properties");
	}
	public WebDriver bringMyDriver() throws IOException
	{
		
		String et = prop.readValue("executionType").toUpperCase().trim();
		switch(et)
		{
			case "LOCAL":
			{
				driver = bringMyLocalDriver();
				break;
			}
			case "REMOTE":
			{ 
				driver = bringMyRemoteDriver();
				break;
			}
			default :
			{
				driver = bringMyLocalDriver();
				break;
			}
		}
		return driver;
	}
	public WebDriver bringMyLocalDriver() throws IOException
	{
		
		String browser=prop.readValue("browser").trim();
		if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "C:/Users/WDrivers/chromedriver.exe");
			driver = new ChromeDriver();
		}
		else if (browser.equalsIgnoreCase("Firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "C:/Users/WDrivers/geckodriver");
			driver = new FirefoxDriver();
		}
		else if (browser.equalsIgnoreCase("IE"))
		{
			System.setProperty("webdriver.ie.driver", "/Users/geeth/Documents/OneDrive - ualberta.ca/Documents1/selenium/IEDriverServer");
			driver = new InternetExplorerDriver();
		}
		else
		{
			System.out.println("Browser type is not supported :" + browser );
		}
		
	//implicit wait
	driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	return driver;
}
	//Using SauceLabs
	public WebDriver bringMyRemoteDriver() throws IOException
	{
		URL myUrl = new URL(prop.readValue("SaucelabsURL")); //IP address of the remote machine on which the execution should trigger
		DesiredCapabilities capabilities = new DesiredCapabilities(); // username,password,OS,browser version
		capabilities.setCapability("name", prop.readValue("ApplicationName"));
	    capabilities.setCapability(CapabilityType.BROWSER_NAME, prop.readValue("browser"));
	    capabilities.setCapability(CapabilityType.VERSION, prop.readValue("BrowserVersion"));
	    capabilities.setCapability(CapabilityType.PLATFORM, prop.readValue("OS"));
	    capabilities.setCapability("screen-resolution", prop.readValue("ScreenResolution"));
	    capabilities.setCapability("username", prop.readValue("SaucelabsUserName"));
	    capabilities.setCapability("accessKey", prop.readValue("SaucelabsAccessKey"));
		driver = new RemoteWebDriver(myUrl,capabilities);
		return driver;
		
		
	}
	
	

}
