package testBatches;

import java.io.IOException;

import org.junit.Test;

import testScenarios.testCases;

public class TestSuites {
	testCases testcases;
	
	public TestSuites() throws IOException {
		testcases= new testCases();
		
	}
@Test	
public void positive() throws InterruptedException {

testcases.validUser();

}

}
