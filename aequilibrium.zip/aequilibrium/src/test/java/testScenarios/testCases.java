package testScenarios;

import java.io.File;
import java.io.IOException;
import java.util.Random;

import org.junit.After;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import appUtils.ActionsUtils;
import appUtils.Driver;
import generalUtils.MiscComp;
import generalUtils.ReadProperties;
import pageObjects.Login;

public class testCases extends MiscComp {
	public static WebDriver driver;
	Login login;
	ReadProperties prop;
	ActionsUtils actions;
	public static ExtentReports extentreports;
	public static ExtentTest parent;
	ExtentTest child;
	Random random;
	String root;
	
	
	public testCases() throws IOException {
		prop=new ReadProperties("Data/swagLabs.properties");
		driver= new Driver().bringMyDriver();
		login = new Login(driver);
		
	
		actions= new ActionsUtils(driver);
		random=new Random();
		int raNum = random.nextInt(99999);
		root = new File(".").getCanonicalPath();
		
		extentreports = new ExtentReports(root+"/Reports/MyReports-"+raNum+".html");
		
		parent = extentreports.startTest("SwagLabs");
					
	}
	
	public void createAndAddChildToParent(String childName) {
		
		child = extentreports.startTest(childName);
		parent.appendChild(child);
	}
	
	
	
@Test	
public void validUser() {
	createAndAddChildToParent("validUser");
	report(child,login.launchApplication(),"launchApplication");
	report(child,login.Credentials(prop.readValue("username"),prop.readValue("password")),"Credentials");
	report(child,login.loginButton(),"loginButton");
}

@Test
public void invalidUser() {
	createAndAddChildToParent("invalidUser");
	report(child,login.launchApplication(),"launchApplication");
	report(child,login.Credentials(prop.readValue("username"),prop.readValue("invalidpwd")),"Credentials");
	report(child,login.loginButton(),"loginButton");
		
	
}

@Test
public void invalidPassword() {
	createAndAddChildToParent("invalidUser");
	report(child,login.launchApplication(),"launchApplication");
	report(child,login.Credentials(prop.readValue("invaliduser"),prop.readValue("password")),"Credentials");
	report(child,login.loginButton(),"loginButton");
		
	
}
@Test
public void blankCredentials() {
	createAndAddChildToParent("blankCredentials");
	report(child,login.launchApplication(),"launchApplication");
	report(child,login.loginButton(),"loginButton");
	
}

	
@Test
public void enterKey() {
	createAndAddChildToParent("enterKey");
	report(child,login.launchApplication(),"launchApplication");
	report(child,login.Credentials(prop.readValue("username"),prop.readValue("password")),"Credentials");
	actions.clickEnter();
	
}


@After
public void teardown() {
	driver.quit();
	extentreports.endTest(parent);
	extentreports.flush();
	extentreports.close();
	
}

	
}
