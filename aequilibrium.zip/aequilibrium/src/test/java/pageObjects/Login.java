package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import generalUtils.ReadProperties;

public class Login {
	
	WebDriver driver;
	ReadProperties prop;
public Login(WebDriver driver) {
	this.driver =driver;
	prop= new ReadProperties("Data/swagLabs.properties");
}
	public boolean launchApplication() {
		System.out.println("Login");
		driver.get(prop.readValue("url"));
		if(driver.getTitle().trim().equals(prop.readValue("eTitle").trim()))
		{
			return true;
		}
		else
		{
			return false;
		}
		
		
	}
	public void launchApplication(String url) {
		System.out.println("Login");
		driver.get(url);
	}
	
	public boolean Credentials(String UN, String PW) {
		System.out.println("validCredentials");
		driver.findElement(By.id("user-name")).sendKeys(UN);
		driver.findElement(By.id("password")).sendKeys(PW);
		//validation code should be written
		return true;
		
	}
	
	public boolean loginButton() {
		System.out.println("loginButton");
		driver.findElement(By.xpath("//input[@id='login-button']")).click();
		//validations should be written
		return true;
		
	}
	
	public void clear() {
		driver.findElement(By.id("user-name")).clear();
	}
}
